import './style.css'

const map = L.map('map').setView([45.4613, 9.1595], 13); 

let allLayers = L.layerGroup(); 
allLayers.addTo(map); 

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap'
}).addTo(map);

function createMarker(lat, lon, nome) {
    const marker = L.marker([lat, lon])
        .bindPopup(`<b>${nome}</b><br>Lat: ${lat}<br>Lon: ${lon}`);
    
    marker.addTo(allLayers); 
}

function clearAllMarkers() {
    allLayers.clearLayers(); 
    console.log("Mappa pulita prima del ricaricamento iniziale.");
}

async function loadMarkers() {
    clearAllMarkers(); 

    try {
        const response = await fetch("http://127.0.0.1:8090/api/collections/Map/records");
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();

        if (Array.isArray(data.items)) {
            data.items.forEach(record => {

                if (record.coordinate && record.coordinate.lat !== undefined && record.coordinate.lon !== undefined) {
                    const nome = record.nome ?? record.titolo ?? "Senza nome";
                    createMarker(record.coordinate.lat, record.coordinate.lon, nome);
                } else if (record.campo) {
                   
                    const parts = record.campo.split(', ');
                    if (parts.length === 2) {
                        const lon = parseFloat(parts[0]);
                        const lat = parseFloat(parts[1]);
                        const nome = record.nome ?? record.titolo ?? "Senza nome";
                        if (!isNaN(lat) && !isNaN(lon)) {
                            createMarker(lat, lon, nome);
                        }
                    }
                }
            });
        }
    } catch (error) {
        console.error("Errore caricamento marker iniziale (Verifica se PocketBase è attivo):", error);
    }
}

loadMarkers(); 

function onMapClick(e) {
    const { lat, lng: lon } = e.latlng;
    const nome = document.getElementById("testo").value || "Senza nome";

    createMarker(lat, lon, nome); 

    fetch("http://127.0.0.1:8090/api/collections/Map/records", {
        method: "POST",
        body: JSON.stringify({
            titolo: nome,
            coordinate: { lat, lon },
            field: {lat: lat, lon: lon } 
        }),
        headers: { "Content-Type": "application/json" }
    })
    .then(res => {
        if (!res.ok) throw new Error(`Salvataggio fallito con stato: ${res.status}`);
        console.log("Salvataggio OK. Il marker resterà visibile."); 

    })
    .catch(err => {
        console.error("Errore salvataggio:", err);
    });
}

map.on('click', onMapClick);